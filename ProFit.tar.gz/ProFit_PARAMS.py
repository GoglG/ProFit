#PARAMETERS OF DATA IMPORT#
#The full path of the the experimental datasets
path = "./RAW"
#Standard error (if no experimental error is available due to a perfect experiment)
STErr = 0.1
#PARAMETERS OF FITTING#
#Tracer concentration (in uM)
Pept = 0.05
#number of monte carlo cycles
interation=250
#initial guess for direct Kd (in uM)
KD = 1
#Graphic mode (0 for showing every datapoints; 1 for showing average and error)
GraphMode = 0
#Plot type (0 = raw; 1 = fraction bound, based on direct fit; 2 = fraction bound, based on actual fit)
PlotTyp = 0
#Scale of the X axis (0 = linear, 1=logaritmic)
xscale = 0
#PARAMETERS OF EVALUATION#
#R^2 limit for a good fit
FitPar = 0.95
#Window tolerance
rtol = 0.2
#Kd tolerance during Comptit3
rtol2 = 0.5





if __name__ == '__main__':
    print ('This is only a parameter file, run ProFit instead!')
