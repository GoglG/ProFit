import sys,os
import configparser
from random import gauss
from scipy import optimize as o
from scipy import stats
import numpy as np
import matplotlib.pylab as plt #linux
# MacOS import matplotlib
# MacOS matplotlib.use("TkAgg")
# MacOS from matplotlib import pylab as plt
from fpdf import FPDF
import tkinter as tk
from tkinter import *
from ProFit_PARAMS import path, Pept, interation, KD, STErr, rtol, rtol2, FitPar, GraphMode, PlotTyp, xscale
version = 'ProFit_v4'
##############################################################
########################FUNCTIONS#############################
##############################################################
COMPLEX = lambda PDZ, PAR, Pept: PAR[1]+(((PAR[2]-PAR[1])*(PDZ+Pept+PAR[0] - ((((PDZ+Pept+PAR[0]) ** 2)-4*PDZ*Pept) ** 0.5)))/(2*Pept))
#COMPTIT function is based on function (17) of doi:10.1021/bi048233g
#KdB -> KD of direct binding
#PAR[0] -> KD of compDoitor binding
#Bo -> Total conc of labeled peptide
#To -> Total conc of unlabeled peptide
#Do -> Total conc of protein
COMPTITnew = lambda To, PAR, Do, Bo, KdB: PAR[1]+(PAR[2]-PAR[1])*((2*(((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**0.5)*(np.cos((np.arccos((-2*(KdB+PAR[0]+Bo+To-Do)**3+9*(KdB+PAR[0]+Bo+To-Do)*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0])-27*((-1)*KdB*PAR[0]*Do))/(2*((((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**3)**0.5))))/3))-(KdB+PAR[0]+Bo+To-Do))/(3*KdB+2*(((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**0.5)*np.cos((np.arccos((-2*(KdB+PAR[0]+Bo+To-Do)**3+9*(KdB+PAR[0]+Bo+To-Do)*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0])-27*((-1)*KdB*PAR[0]*Do))/(2*((((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**3)**0.5))))/3)-(KdB+PAR[0]+Bo+To-Do)))
COMPTITnewforce = lambda To, PAR, Do, Bo, KdB, WIN: WIN[0]+(WIN[1]-WIN[0])*((2*(((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**0.5)*(np.cos((np.arccos((-2*(KdB+PAR[0]+Bo+To-Do)**3+9*(KdB+PAR[0]+Bo+To-Do)*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0])-27*((-1)*KdB*PAR[0]*Do))/(2*((((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**3)**0.5))))/3))-(KdB+PAR[0]+Bo+To-Do))/(3*KdB+2*(((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**0.5)*np.cos((np.arccos((-2*(KdB+PAR[0]+Bo+To-Do)**3+9*(KdB+PAR[0]+Bo+To-Do)*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0])-27*((-1)*KdB*PAR[0]*Do))/(2*((((KdB+PAR[0]+Bo+To-Do)**2-3*((To-Do)*KdB+(Bo-Do)*PAR[0]+KdB*PAR[0]))**3)**0.5))))/3)-(KdB+PAR[0]+Bo+To-Do)))
##############################################################
#######################SUBROUTINES############################
##############################################################
def importdata(pathfile, STErr):
    FILE = open(pathfile, 'r')
    all_lines = FILE.readlines()
    X = []
    Y = []
    aY = []
    sY = []
    rX = []
    CX = []
    CY = []
    aCY = []
    sCY = []
    rCX = []
    for line in all_lines[0:]:
        line=line.replace(',','.')
    ProtConc = float(all_lines[0])
    Force = float(all_lines[1])
    for line in all_lines[2:]:
        #print line
        linesplit=line.split("\t")
        #print(linesplit)
        X.append(float(linesplit[0]))
        Y.append(float(linesplit[1]))
        X.append(float(linesplit[0]))
        Y.append(float(linesplit[2]))
        X.append(float(linesplit[0]))
        Y.append(float(linesplit[3]))
        DIR = [float(linesplit[1]),float(linesplit[2]),float(linesplit[3])]
        aY.append(np.average(DIR))
        sY.append(np.std(DIR))
        rX.append(float(linesplit[0]))
        if ProtConc > 0:
            CX.append(float(linesplit[4]))
            CY.append(float(linesplit[5]))
            CX.append(float(linesplit[4]))
            CY.append(float(linesplit[6]))
            CX.append(float(linesplit[4]))
            CY.append(float(linesplit[7]))  
            COM = [float(linesplit[5]),float(linesplit[6]),float(linesplit[7])]
            aCY.append(np.average(COM))
            #add standard dev to "perfect" points
            if np.std(COM) == 0:
                sCY.append(STErr)
            else:
                sCY.append(np.std(COM))   
            rCX.append(float(linesplit[4]))
    return ProtConc, Force, X, Y, aY, sY, rX, CX, CY, aCY, sCY, rCX
##############################################################
##########################DATA################################
##############################################################
root = tk.Tk()
v = tk.IntVar()
root.title(version)
v.set(0)  # initializing the choice
ops = [("Fit every file in a folder (default)"),("Fit every file in a folder (custom)"),("Fit two file (custom)"),("Run simulation")]
tk.Label(root, 
         text="Choose a task:", justify = tk.LEFT, padx = 20).pack()
for val, ops in enumerate(ops):
    tk.Radiobutton(root, 
                  text=ops,
                  padx = 20, 
                  variable=v,
                  value=val).pack(anchor=tk.W)
tk.Button(root, text='Continue', width=5, command=root.destroy).pack()
root.bind("<Return>", lambda e: root.destroy())
root.mainloop()
if v.get() < 2:
    if v.get() == 1:
        ##############################################################
        ####################MANUAL PARAMETERS#########################
        ##############################################################
        master = Tk()
        master.title("ProFit_PARAMS")
        w = tk.Label(master, font = "Verdana 10 bold", text='#####PARAMETERS#####').grid(row=0, column=1)
        Label(master, text="PATH = ").grid(row=1)
        epath = Entry(master)
        epath.insert(10,path)
        epath.grid(row=1, column=1)
        Label(master, text="Tracer concentration = ").grid(row=2)
        epept = Entry(master)
        epept.insert(10,Pept)
        epept.grid(row=2, column=1)
        Label(master, text="Number of Monte-Carlo cycles = ").grid(row=3)
        einteration = Entry(master)
        einteration.insert(10,interation)
        einteration.grid(row=3, column=1)
        Label(master, text="Initial KD = ").grid(row=4)
        eKD = Entry(master)
        eKD.insert(10,KD)
        eKD.grid(row=4, column=1)
        Label(master, text="Standard error of measurements = ").grid(row=5)
        eSTErr = Entry(master)
        eSTErr.insert(10,STErr)
        eSTErr.grid(row=5, column=1)
        Label(master, text="R^2 limit for a good fit = ").grid(row=6)
        eFitPar = Entry(master)
        eFitPar.insert(10,FitPar)
        eFitPar.grid(row=6, column=1)
        Label(master, text="Kd tolerance during Comptit3 = ").grid(row=7)
        ertol2 = Entry(master)
        ertol2.insert(10,rtol2)
        ertol2.grid(row=7, column=1)
        Label(master, text="Window tolerance = ").grid(row=8)
        ertol = Entry(master)
        ertol.insert(10,rtol)
        ertol.grid(row=8, column=1)
        Label(master, text="Graphic mode = ").grid(row=9)
        eGraphMode = Entry(master)
        eGraphMode.insert(10,GraphMode)
        eGraphMode.grid(row=9, column=1)
        Label(master, text="Plot type = ").grid(row=10)
        ePlotTyp = Entry(master)
        ePlotTyp.insert(10,PlotTyp)
        ePlotTyp.grid(row=10, column=1)
        Label(master, text="X axis scale = ").grid(row=11)
        exscale = Entry(master)
        exscale.insert(10,xscale)
        exscale.grid(row=11, column=1)
        Label(master).grid(row=12)
        button = tk.Button(master, text='Modify & Accept', width=12, command=master.quit)
        button.grid(row=13, column=1)
        master.bind("<Return>", lambda e: master.quit())
        mainloop()
        path = epath.get()
        Pept = float(epept.get())
        interation = int(einteration.get())
        KD = float(eKD.get())
        STErr = float(eSTErr.get())
        rtol = float(ertol.get())
        rtol2 = float(ertol2.get())
        FitPar = float(eFitPar.get())
        PlotTyp = int(ePlotTyp.get())
        GraphMode = int(eGraphMode.get())
        xscale = int(exscale.get())
    ##############################################################
    ######################READING DATA############################
    ##############################################################
    #MacOs files = [f for f in os.listdir( path ) if not f.startswith('.')]
    files = os.listdir( path ) #linux
    for file in files:
        pathfile = os.path.join(path,file)
        data = importdata(pathfile, STErr)
        ProtConc = data[0]
        Force =  data[1]
        X = data[2]
        Y = data[3]
        aY = data[4]
        sY = data[5]
        rX = data[6]
        CX = data[7]
        CY = data[8]
        aCY = data[9]
        sCY = data[10]
        rCX = data[11]
        X=np.array(X)
        rX=np.array(rX)
        Y=np.array(Y)
        sY=np.array(sY)
        aY=np.array(aY)
        if ProtConc > 0:
            rCX=np.array(rCX)
            CX=np.array(CX)
            CY=np.array(CY)
            aCY=np.array(aCY)
            sCY=np.array(sCY)
            CRUmax = np.max(CY)
            CRUmin = np.min(CY)
        #SET ALTERNATIVE X AND Y LABELS HERE#########################
        #You can use the name of the file
        labelx1 = '[' + file.split('.')[2] + r'] ($\mu$M)'
        #labelx1 = r'[protein] ($\mu$M)'
        if ProtConc > 0:
            labelx2 = '[' + file.split('.')[3] + r'] ($\mu$M)'
        #labelx2 = r'[peptide] ($\mu$M)'
        RUmax = np.max(Y)
        RUmin = np.min(Y)
        np.seterr('ignore')
        ##############################################################
        #########################Monte  Carlo#########################
        ##############################################################
        points = len(rX)
        dirkd = []
        dirmin = []
        dirmax = []
        comp1kd = []
        comp1min = []
        comp1max = []
        comp2kd = []
        comp2min = []
        comp2max = []
        for m in range(0, interation):
            #generate random dataset
            rCY = []
            rY = []
            for i in range(0,points):    #gauss        
                rY.append(aY[i] + gauss(0 , sY[i]))
                if ProtConc > 0:
                    rCY.append(aCY[i] + gauss(0 , sCY[i]))
            #direct fitting
            rY=np.array(rY)
            PAR=np.array([KD, RUmin, RUmax])
            residuals = lambda PAR, rX, rY, Pept, fun: rY - COMPLEX(rX, PAR, Pept)    
            v, covar = o.leastsq(residuals, PAR, args=(rX, rY, Pept, COMPLEX))
            Kd = v[0]
            dirkd.append(v[0])
            dirmin.append(v[1])
            dirmax.append(v[2])
            #competitive fitting
            if ProtConc > 0:
                #Restrained fit
                PAR3=np.array((0.5*v[0]))
                WIN=np.array((v[1], v[2]))
                residualscomptit2 = lambda PAR3, rCX, rCY, ProtConc, Pept, WIN, Kd, fun: rCY - COMPTITnewforce(rCX, PAR3, ProtConc, Pept, Kd, WIN)
                (v3, cov_v3) = o.leastsq(residualscomptit2, PAR3, args=(rCX, rCY, ProtConc, Pept, WIN, Kd, COMPTITnewforce))
                #Unrestrained fit
                PAR4=np.array([2*v[0], v[1], v[2]])
                residualscomptit3 = lambda PAR4, rCX, rCY, ProtConc, Pept, Kd, fun: rCY - COMPTITnew(rCX, PAR4, ProtConc, Pept, Kd)
                (v4, cov_v4) = o.leastsq(residualscomptit3, PAR4, args=(rCX, rCY, ProtConc, Pept, Kd, COMPTITnew))
                comp1kd.append(v4[0])
                comp1min.append(v4[1])
                comp1max.append(v4[2])
                comp2kd.append(v3[0])
                comp2min.append(v[1])
                comp2max.append(v[2])    
        ##############################################################
        ##########################STATISTICS##########################
        ##############################################################
        #General statistics after MC
        Cmax = np.max(X)
        Cmin = np.min(X) 
        Cminlog= min([n for n in X  if n>0]) 
        avdirkd = np.average(dirkd)
        avdirmin = np.average(dirmin)
        avdirmax = np.average(dirmax)
        sddirkd = np.std(dirkd)
        v=np.array((avdirkd, avdirmin, avdirmax))
        if xscale == 0:
            Conc = np.linspace(0,Cmax+0.5,1000)
        else:
            Conc = np.linspace(Cminlog/2,Cmax*2,3000)
        Smod = COMPLEX(Conc, v, Pept)
        if ProtConc > 0:
            CCmax = np.max(CX)
            CCmin = np.min(CX)
            CCminlog= min([n for n in CX  if n>0]) 
            avcomp1kd = np.average(comp1kd)
            avcomp1min = np.average(comp1min)
            avcomp1max = np.average(comp1max)
            avcomp2kd = np.average(comp2kd)
            avcomp2min = np.average(comp2min)
            avcomp2max = np.average(comp2max)
            sdcomp1kd = np.std(comp1kd)
            sdcomp2kd = np.std(comp2kd)
            v3=np.array((avcomp2kd, avcomp2min, avcomp2max))
            v4=np.array((avcomp1kd, avcomp1min, avcomp1max))
            if xscale == 0:
                Conc3 = np.linspace(0,CCmax+5,1000)
            else:
                Conc3 = np.linspace(CCminlog/2,CCmax*2,3000)
            Smod3 = COMPTITnew(Conc3, v3, ProtConc, Pept, Kd)
            Smod4 = COMPTITnew(Conc3, v4, ProtConc, Pept, Kd)
        #reducedCHI^2 stat
        EXPdir = COMPLEX(rX, v, Pept)
        diff = ((aY-EXPdir) ** 2)/sY
        freedomdir = len(rX) - 3
        redchidir = sum(diff) / freedomdir
        if ProtConc > 0:
            freedomcomp1 = freedomdir = len(rX) - 3
            freedomcomp2 = freedomdir = len(rX) - 1
            EXPcomp1 = COMPTITnew(rCX, v4, ProtConc, Pept, Kd)
            diffcomp1 = ((aCY-EXPcomp1) ** 2)/sCY
            redchicomp1 = sum(diffcomp1)  / freedomcomp1
            EXPcomp2 = COMPTITnew(rCX, v3, ProtConc, Pept, Kd)
            diffcomp2 = ((aCY-EXPcomp2) ** 2)/sCY
            redchicomp2 = sum(diffcomp2) / freedomcomp2
            chicomps = [redchicomp1, redchicomp2]
            minchicomps = min(chicomps)
        #R^2 stat
        dirmean = np.mean(aY)
        SStotdir = (aY-dirmean) ** 2
        SSresdir = (aY-EXPdir) ** 2
        Rsqdir = 1 - (sum(SSresdir)/sum(SStotdir))
        if ProtConc > 0:
            compmean = np.mean(aCY)
            SStotcomp = (aCY-compmean) ** 2
            SSrescomp1 = (aCY-EXPcomp1) ** 2
            Rsqcomp1 = 1 - (sum(SSrescomp1)/sum(SStotcomp))
            SSrescomp2 = (aCY-EXPcomp2) ** 2
            Rsqcomp2 = 1 - (sum(SSrescomp2)/sum(SStotcomp))
        ##############################################################
        ######################generating figures######################
        ##############################################################
        #figure names
        FigName = file.split('.')[0] + file.split('.')[1] +'direct.png'
        FigNam1 = file.split('.')[0] + file.split('.')[1] +'dirempty.png'
        if ProtConc > 0:
            FigNamec = file.split('.')[0] + file.split('.')[1] + 'comptit2.png'
            FigNamed = file.split('.')[0] + file.split('.')[1] + 'comptit1.png'
            FigNam2 = file.split('.')[0] + file.split('.')[1] + 'compempty.png'
        #parameters for final figures
        Cwinddir=Cmax-Cmin
        FPwindD=RUmax-RUmin
        if ProtConc > 0:
            CCwinddir=CCmax-CCmin
            if RUmax > CRUmax:
                plotmax = RUmax
            else:
                plotmax = CRUmax

            if RUmin < CRUmin:
                plotmin = RUmin
            else:
                plotmin = CRUmin
            FPwindC=plotmax-plotmin
        #Generating "Fraction bound" values
        if PlotTyp > 0:
            aYplt = (aY - v[1])/(v[2]-v[1])
            sYplt = (sY )/(v[2]-v[1])
            Yplt = (Y  - v[1])/(v[2]-v[1])
            RUminplt = (RUmin  - v[1])/(v[2]-v[1])
            RUmaxplt = (RUmax  - v[1])/(v[2]-v[1])
            FPwindDplt = (FPwindD )/(v[2]-v[1])
            Smodplt = (Smod  - v[1])/(v[2]-v[1])
            labely = 'Fraction Bound'
        else:
            aYplt = aY 
            sYplt = sY 
            Yplt = Y 
            RUminplt = RUmin 
            RUmaxplt = RUmax 
            FPwindDplt = FPwindD 
            Smodplt = Smod 
            labely = 'Anisotropy (mP)'
        plt.close()
        #DIRECT plot without fit
        ax = plt.subplot(111)
        if GraphMode > 0:
            plt.errorbar(rX, aYplt, sYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
        else:
            plt.plot(X, Yplt, 'ok', markersize=8)
        if xscale == 0:
            plt.axis([Cmin-Cwinddir*0.05,Cmax+Cwinddir*0.05,RUminplt-FPwindDplt*0.1,RUmaxplt+FPwindDplt*0.15])
        else:
            ax.set_xscale('log')
            plt.axis([0,Cmax+Cwinddir*0.05,RUminplt-FPwindDplt*0.1,RUmaxplt+FPwindDplt*0.15])
            plt.subplots_adjust(bottom=0.15,left = 0.175)
        plt.title(file.split('.')[0], fontsize=20)
        ax.set_xlabel(labelx1, fontsize=19)
        ax.set_ylabel(labely, fontsize=19)
        ax.tick_params(labelsize=16)
        plt.tight_layout()
        plt.savefig('pics/' + FigNam1)
        plt.close()
        #DIRECT plot
        ax = plt.subplot(111) 
        plt.plot(Conc, Smodplt, '-r', linewidth=3) 
        #plt.hold(True)
        if GraphMode > 0:
            plt.errorbar(rX, aYplt, sYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
        else:
            plt.plot(X, Yplt, 'ok', markersize=8)
        plt.title(file.split('.')[0], fontsize=20)
        if v[0] < 0.1:
            rescaled = v[0] * 1000
            rescaledsd = sddirkd * 1000
            plt.text(Cmin-Cwinddir*0.02, RUmaxplt+FPwindDplt*0.02, 'K' + r'$_d$' + ' = ' + str(format(rescaled,'.2f')) + ' +/- ' + str(format(rescaledsd,'.2f')) + r' nM', fontsize=20)
        else:
            plt.text(Cmin-Cwinddir*0.02, RUmaxplt+FPwindDplt*0.02, 'K' + r'$_d$' + ' = ' + str(format(v[0],'.2f')) + ' +/- ' + str(format(sddirkd,'.2f')) + r' $\mu$M', fontsize=20)
        ax.set_xlabel(labelx1, fontsize=19)
        ax.set_ylabel(labely, fontsize=19)
        ax.tick_params(labelsize=16)
        if xscale == 0:
            plt.axis([Cmin-Cwinddir*0.05,Cmax+Cwinddir*0.05,RUminplt-FPwindDplt*0.1,RUmaxplt+FPwindDplt*0.15])
        else:
            ax.set_xscale('log')
            plt.axis([Cminlog/2,Cmax*2,RUminplt-FPwindDplt*0.1,RUmaxplt+FPwindDplt*0.15])
            plt.subplots_adjust(bottom=0.15,left = 0.175)
        plt.tight_layout()
        plt.savefig('pics/' + FigName)
        plt.close()
        if ProtConc >0:
            if PlotTyp == 1:
                plotminplt = (plotmin - v[1])/(v[2]-v[1])
                plotmaxplt = (plotmax - v[1])/(v[2]-v[1])
                aCYplt = (aCY - v[1])/(v[2]-v[1])
                sCYplt = (sCY )/(v[2]-v[1])
                CYplt = (CY - v[1])/(v[2]-v[1])
                FPwindCplt = (FPwindC )/(v[2]-v[1])
                Smod3plt = (Smod3 - v[1])/(v[2]-v[1])
                Smod4plt = (Smod4 - v[1])/(v[2]-v[1])
                CRUmaxplt = (CRUmax - v[1])/(v[2]-v[1])
            else:
                aCYplt = aCY
                sCYplt = sCY
                CYplt = CY
                plotminplt = plotmin
                plotmaxplt = plotmax
                FPwindCplt = FPwindC
                Smod3plt = Smod3
                Smod4plt = Smod4
                CRUmaxplt = CRUmax
            #COMPETITIVE plot without fit
            ax = plt.subplot(111)
            if GraphMode > 0:
                plt.errorbar(rCX, aCYplt, sCYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
            else:
                plt.plot(CX, CYplt, 'ok', markersize=8)
            if xscale == 0:
                plt.axis([CCmin-CCwinddir*0.05,CCmax+CCwinddir*0.05,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
            else:
                ax.set_xscale('log')
                plt.axis([CCminlog/2,CCmax*2,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
                plt.subplots_adjust(bottom=0.15,left = 0.175)
            plt.title(file.split('.')[1], fontsize=20)
            ax.set_xlabel(labelx2, fontsize=19)
            ax.set_ylabel(labely, fontsize=19)
            ax.tick_params(labelsize=16)
            plt.tight_layout()
            plt.savefig('pics/' + FigNam2)
            plt.close()
            #COMPTIT2 plot
            if PlotTyp > 1:
                plotminplt = (plotmin - v3[1])/(v3[2]-v3[1])
                plotmaxplt = (plotmax - v3[1])/(v3[2]-v3[1])
                aCYplt = (aCY - v3[1])/(v3[2]-v3[1])
                sCYplt = (sCY )/(v3[2]-v3[1])
                CYplt = (CY - v3[1])/(v3[2]-v3[1])
                FPwindCplt = (FPwindC )/(v3[2]-v3[1])
                Smod3plt = (Smod3 - v3[1])/(v3[2]-v3[1])
                CRUmaxplt = (CRUmax - v3[1])/(v3[2]-v3[1])
            ax = plt.subplot(111)
            plt.plot(Conc3, Smod3plt, '-r', linewidth=3)
            #plt.hold(True)
            if GraphMode > 0:
                plt.errorbar(rCX, aCYplt, sCYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
            else:
                plt.plot(CX, CYplt, 'ok', markersize=8)
            if xscale == 0:
                plt.axis([CCmin-CCwinddir*0.05,CCmax+CCwinddir*0.05,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
            else:
                ax.set_xscale('log')
                plt.axis([CCminlog/2,CCmax*2,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
                plt.subplots_adjust(bottom=0.15,left = 0.175)
            plt.title(file.split('.')[1], fontsize=20)
            if v3[0] < 0.1:
                rescaled = v3[0] * 1000
                rescaledsd = sdcomp2kd * 1000
                plt.text(CCmin-CCwinddir*0.02, CRUmaxplt+FPwindCplt*0.05, 'K' + r'$_d$' + ' = ' + str(format(rescaled,'.2f')) + ' +/- ' + str(format(rescaledsd,'.2f')) + ' nM', fontsize=20)
            else:
                plt.text(CCmin-CCwinddir*0.02, CRUmaxplt+FPwindCplt*0.05, 'K' + r'$_d$' + ' = ' + str(format(v3[0],'.2f')) + ' +/- ' + str(format(sdcomp2kd,'.2f')) + r' $\mu$M', fontsize=20)
            ax.set_xlabel(labelx2, fontsize=19)
            ax.set_ylabel(labely, fontsize=19)
            ax.tick_params(labelsize=16)
            plt.tight_layout()
            plt.savefig('pics/' + FigNamec)
            plt.close()
            #COMPTIT1 plot
            if PlotTyp > 1:
                plotminplt = (plotmin - v4[1])/(v4[2]-v4[1])
                plotmaxplt = (plotmax - v4[1])/(v4[2]-v4[1])
                aCYplt = (aCY - v4[1])/(v4[2]-v4[1])
                sCYplt = (sCY )/(v4[2]-v4[1])
                CYplt = (CY - v4[1])/(v4[2]-v4[1])
                FPwindCplt = (FPwindC )/(v4[2]-v4[1])
                Smod4plt = (Smod4 - v4[1])/(v4[2]-v4[1])
                CRUmaxplt = (CRUmax - v4[1])/(v4[2]-v4[1])
            ax = plt.subplot(111)
            plt.plot(Conc3, Smod4plt, '-r', linewidth=3) 
            #plt.hold(True)
            if GraphMode > 0:
                plt.errorbar(rCX, aCYplt, sCYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
            else:
                plt.plot(CX, CYplt, 'ok', markersize=8)
            if xscale == 0:
                plt.axis([CCmin-CCwinddir*0.05,CCmax+CCwinddir*0.05,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
            else:
                ax.set_xscale('log')
                plt.axis([CCminlog/2,CCmax*2,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
                plt.subplots_adjust(bottom=0.15,left = 0.175)
            plt.title(file.split('.')[1], fontsize=20)
            if v4[0] < 0.1:
                rescaled = v4[0] * 1000
                rescaledsd = sdcomp1kd * 1000
                plt.text(CCmin-CCwinddir*0.02, CRUmaxplt+FPwindCplt*0.05, 'K' + r'$_d$' + ' = '  + str(format(rescaled,'.2f')) + ' +/- ' + str(format(rescaledsd,'.2f')) + ' nM', fontsize=20)
            else:
                plt.text(CCmin-CCwinddir*0.02, CRUmaxplt+FPwindCplt*0.05, 'K' + r'$_d$' + ' = '  + str(format(v4[0],'.2f')) + ' +/- ' + str(format(sdcomp1kd,'.2f')) + r' $\mu$M', fontsize=20)
            ax.set_xlabel(labelx2, fontsize=19)
            ax.set_ylabel(labely, fontsize=19)
            ax.tick_params(labelsize=16)
            plt.tight_layout()
            plt.savefig('pics/' + FigNamed)
            plt.close()
        ##############################################################
        ####################generating pdf summary####################
        ##############################################################
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font('Arial', 'B', 16)
        pdf.text(50, 8, str(file))
        pdf.text(100, 20, 'Direct titration')
        pdf.set_font('Arial', '', 16)
        if v[0] < 0.1:
            rescaled = v[0] * 1000
            pdf.text(100, 30, 'Kd = ' + str(format(rescaled,'.2f')) + ' nM')
        else:
            pdf.text(100, 30, 'Kd = ' + str(format(v[0],'.2f')) + ' uM')
        pdf.text(100, 40, 'min = ' + str(format(v[1],'.2f')) + ' mP')
        pdf.text(100, 50, 'max = ' + str(format(v[2],'.2f')) + ' mP')
        pdf.text(100, 60, 'red Chi^2 = ' + str(format(redchidir,'.2f'))+'   R^2 = ' + str(format(Rsqdir,'.2f')))
        pdf.set_font('Arial', 'I', 16)
        pdf.text(100, 70, 'tracer = ' + str(format(Pept,'.2f')) + ' uM (fixed)')
        pdf.set_font('Arial', 'B', 16)
        if ProtConc > 0:
            #COMP1
            pdf.text(100,90,'Unrestrained fit')
            pdf.set_font('Arial', '', 16)
            if v4[0] < 0.1:
                rescaled = v4[0] * 1000
                pdf.text(100, 100, 'Kd = ' + str(format(rescaled,'.2f')) + ' nM')
            else:
                pdf.text(100, 100, 'Kd = ' + str(format(v4[0],'.2f')) + ' uM')  
            pdf.text(100, 110, 'min = ' + str(format(v4[1],'.2f')) + ' mP')
            pdf.text(100, 120, 'max = ' + str(format(v4[2],'.2f')) + ' mP')
            pdf.text(100, 130, 'red Chi^2 = ' + str(format(redchicomp1,'.2f')) +'   R^2 = ' + str(format(Rsqcomp1,'.2f')))
            pdf.set_font('Arial', 'I', 16)
            #pdf.text(100, 130, 'tracer = ' + str(format(Pept,'.2f')) + ' uM')
            pdf.text(100, 80, 'Prot = ' + str(format(ProtConc,'.2f')) + ' uM (fixed)')
            dif = v[0] - v4[0]
            wind = v[2] - v[1]  
            wind1 = v4[2] - v4[1]
            mindif = np.isclose(wind, wind1, rtol)
            pdf.set_font('Arial', 'I', 16)
            if mindif:
                yrange = np.isclose(v[2], v3[2], rtol)
                if yrange:
                    if minchicomps == redchicomp1:
                        pdf.set_font('Arial', 'IU', 16)
                        pdf.text(100, 140, 'Recommended function')
                    else:
                        if Rsqcomp1 > FitPar:
                            pdf.text(100, 140, 'Good fit')
                        else:
                            pdf.text(100, 140, 'Poor fit')
                else:
                    pdf.text(100, 140, 'Y range is suspicious')
            else:
                pdf.text(100, 140, 'Experimental window is suspicious')
            pdf.set_font('Arial', 'B', 16)
            #COMP2
            pdf.text(100,160,'Restrained fit')
            pdf.set_font('Arial', '', 16)
            if v3[0] < 0.1*v[0]:
                if v3[0] < 0.1:
                    rescaled = v3[0] * 1000
                    pdf.text(100, 170, 'Kd upper limit! = ' + str(format(v[0]*100,'.2f')) + ' nM')
                else:
                    pdf.text(100, 170, 'Kd upper limit! = ' + str(format(v[0]*0.1,'.2f')) + ' uM') 
            else:
                if v3[0] < 0.1:
                    rescaled = v3[0] * 1000
                    pdf.text(100, 170, 'Kd = ' + str(format(rescaled,'.2f')) + ' nM')
                else:
                    pdf.text(100, 170, 'Kd = ' + str(format(v3[0],'.2f')) + ' uM')
            pdf.text(100, 180, 'Range was fixed during fitting')
            pdf.text(100, 200, 'red Chi^2 = ' + str(format(redchicomp2,'.2f'))+'   R^2 = ' + str(format(Rsqcomp2,'.2f')))
            dif = v[0] - v3[0]
            wind2 = v3[2] - v3[1]
            mindif = np.isclose(wind, wind2, rtol)
            pdf.set_font('Arial', 'I', 16)
            if mindif:
                yrange = np.isclose(v[2], v3[2], rtol)
                if yrange:
                    if minchicomps == redchicomp2:
                        pdf.set_font('Arial', 'IU', 16)
                        pdf.text(100, 210, 'Recommended function')
                    else:
                        if Rsqcomp2 > FitPar:
                            pdf.text(100, 210, 'Good fit')
                        else:
                            pdf.text(100, 210, 'Poor fit')
                else:
                    pdf.text(100, 210, 'Y range is suspicious')
            else:
               pdf.text(100, 210, 'Experimental window is suspicious')
            pdf.image('pics/' + FigNamed, 10, 80, 85)
            pdf.image('pics/' + FigNamec, 10, 150, 85)
        pdf.image('pics/' + FigName, 10, 10, 85)
        pdf.set_font('Arial', 'I', 10)
        pdf.text(170, 295, 'Created by ' + version)
        pdf.output(str(file) +'.pdf')
        pdf.close()
        pdf.add_page()
elif v.get() == 2:
    ##############################################################
    #######################PARAMETERS#############################
    ##############################################################
    master = Tk()
    master.title("ProFit_PARAMS")
    w = tk.Label(master, font = "Verdana 10 bold", text='#####PARAMETERS#####').grid(row=0, column=1)
    Label(master, text="PATH (1) = ").grid(row=1)
    epath = Entry(master)
    epath.insert(10,path)
    epath.grid(row=1, column=1)
    Label(master, text="PATH (2) = ").grid(row=2)
    epath2 = Entry(master)
    epath2.insert(10,path)
    epath2.grid(row=2, column=1)
    Label(master, text="Compare direct (0) or competitive data (1)  = ").grid(row=3)
    etypdir1 = Entry(master)
    etypdir1.insert(10,1)
    etypdir1.grid(row=3, column=1)
    #Label(master, text="Type of direct fit (2) (none, direct) = ").grid(row=4)
    #etypdir2 = Entry(master)
    #etypdir2.insert(10,1)
    #etypdir2.grid(row=4, column=1)
    #Label(master, text="Type of competitive fit (1) (none, comptit1, comptit2, comptit3) = ").grid(row=5)
    #etypcomp1 = Entry(master)
    #etypcomp1.insert(10,1)
    #etypcomp1.grid(row=5, column=1)
    #Label(master, text="Type of competitive fit (2) (none, comptit1, comptit2, comptit3) = ").grid(row=6)
    #etypcomp2 = Entry(master)
    #etypcomp2.insert(10,1)
    #etypcomp2.grid(row=6, column=1)
    Label(master, text="Tracer concentration = ").grid(row=13)
    epept = Entry(master)
    epept.insert(10,Pept)
    epept.grid(row=13, column=1)
    Label(master, text="Number of Monte-Carlo cycles = ").grid(row=14)
    einteration = Entry(master)
    einteration.insert(10,250)
    einteration.grid(row=14, column=1)
    Label(master, text="Initial KD = ").grid(row=15)
    eKD = Entry(master)
    eKD.insert(10,KD)
    eKD.grid(row=15, column=1)
    Label(master, text="Standard error of measurements = ").grid(row=16)
    eSTErr = Entry(master)
    eSTErr.insert(10,STErr)
    eSTErr.grid(row=16, column=1)
    Label(master, text="Graphic mode = ").grid(row=17)
    eGraphMode = Entry(master)
    eGraphMode.insert(10,GraphMode)
    eGraphMode.grid(row=17, column=1)
    #Label(master, text="Plot type = ").grid(row=18)
    #ePlotTyp = Entry(master)
    #ePlotTyp.insert(10,PlotTyp)
    #ePlotTyp.grid(row=18, column=1)
    Label(master, text="Y label = ").grid(row=19)
    elabely = Entry(master)
    elabely.insert(10,'Anisotropy (mP)')
    elabely.grid(row=19, column=1)
    Label(master, text="X axis scale = ").grid(row=21)
    exscale = Entry(master)
    exscale.insert(10,xscale)
    exscale.grid(row=21, column=1)
    Label(master, text="Title of direct plot = ").grid(row=22)
    edirtitl = Entry(master)
    edirtitl.insert(10,'Direct measurement')
    edirtitl.grid(row=22, column=1)
    Label(master, text="Title of competitive plot = ").grid(row=23)
    ecomptitl = Entry(master)
    ecomptitl.insert(10,'Competitive measurement')
    ecomptitl.grid(row=23, column=1)
    Label(master, text="Title of direct X axis = ").grid(row=24)
    edirXtitl = Entry(master)
    edirXtitl.insert(10,'protein')
    edirXtitl.grid(row=24, column=1)
    Label(master, text="Title of competitive X axis = ").grid(row=25)
    ecompXtitl = Entry(master)
    ecompXtitl.insert(10,'peptide')
    ecompXtitl.grid(row=25, column=1)
    Label(master).grid(row=26)
    button = tk.Button(master, text='Modify & Accept', width=16, command=master.quit)
    button.grid(row=27, column=1)
    master.bind("<Return>", lambda e: master.quit())
    mainloop()
    comptitl = ecomptitl.get()
    dirtitl = edirtitl.get()
    dirXtitl = edirXtitl.get()
    compXtitl = ecompXtitl.get()
    path = epath.get()
    path2 = epath2.get()
    Pept = float(epept.get())
    interation = int(einteration.get())
    KD = float(eKD.get())
    STErr = float(eSTErr.get())
    #PlotTyp = int(ePlotTyp.get())
    GraphMode = int(eGraphMode.get())
    xscale = int(exscale.get())
    typdir1 = int(etypdir1.get())
    #typdir2 = int(etypdir2.get())
    labely = elabely.get()
    #typcomp2 = int(etypcomp2.get())
    #typcomp1 = int(etypcomp1.get())
    ##############################################################
    #########################DATA 1###############################
    ##############################################################
    data = importdata(path, STErr)
    ProtConc = data[0]
    Force =  data[1]
    X = data[2]
    Y = data[3]
    aY = data[4]
    sY = data[5]
    rX = data[6]
    CX = data[7]
    CY = data[8]
    aCY = data[9]
    sCY = data[10]
    rCX = data[11]
    X=np.array(X)
    rX=np.array(rX)
    Y=np.array(Y)
    sY=np.array(sY)
    aY=np.array(aY)
    if ProtConc > 0:
        rCX=np.array(rCX)
        CX=np.array(CX)
        CY=np.array(CY)
        aCY=np.array(aCY)
        sCY=np.array(sCY)
        CRUmax = np.max(CY)
        CRUmin = np.min(CY)
    ##############################################################
    #########################DATA 2###############################
    ##############################################################
    data = importdata(path2, STErr)
    ProtConc2 = data[0]
    Force2 =  data[1]
    X2 = data[2]
    Y2 = data[3]
    aY2 = data[4]
    sY2 = data[5]
    rX2 = data[6]
    CX2 = data[7]
    CY2 = data[8]
    aCY2 = data[9]
    sCY2 = data[10]
    rCX2 = data[11]
    X2=np.array(X2)
    rX2=np.array(rX2)
    Y2=np.array(Y2)
    sY2=np.array(sY2)
    aY2=np.array(aY2)
    if ProtConc2 > 0:
        rCX2=np.array(rCX2)
        CX2=np.array(CX2)
        CY2=np.array(CY2)
        aCY2=np.array(aCY2)
        sCY2=np.array(sCY2)
        CRUmax2 = np.max(CY2)
        CRUmin2 = np.min(CY2)
    labelx1 = '[' + dirXtitl + r'] ($\mu$M)'
    labelx2 = '[' + compXtitl + r'] ($\mu$M)'
    RUmax = np.max([Y, Y2])
    RUmin = np.min([Y, Y2])
    np.seterr('ignore')
    ##############################################################
    #########################Monte  Carlo#########################
    ##############################################################
    #print aCY
    #print aCY2
    points = len(rX)
    dirkd = []
    dirmin = []
    dirmax = []
    dirkd2 = []
    dirmin2 = []
    dirmax2 = []
    comp1kd = []
    comp1min = []
    comp1max = []
    comp2kd = []
    comp2min = []
    comp2max = []
    #Fit of direct datasets#
    for m in range(0, interation):
        #generate random dataset
        rCY = []
        rY = []
        rCY2 = []
        rY2 = []
        for i in range(0,points):    #gauss        
            rY.append(aY[i] + gauss(0 , sY[i]))
            rY2.append(aY2[i] + gauss(0 , sY2[i]))
            if ProtConc > 0:
                rCY.append(aCY[i] + gauss(0 , sCY[i]))
            if ProtConc2 > 0:
                rCY2.append(aCY2[i] + gauss(0 , sCY2[i]))
        rY1=np.array(rY)
        rY2=np.array(rY2)
        #direct fitting1
        PAR=np.array([KD, RUmin, RUmax])
        residuals = lambda PAR, rX, rY, Pept, fun: rY - COMPLEX(rX, PAR, Pept)    
        v, covar = o.leastsq(residuals, PAR, args=(rX, rY, Pept, COMPLEX))
        Kd = v[0]
        dirkd.append(v[0])
        dirmin.append(v[1])
        dirmax.append(v[2])
        #direct fitting2
        PAR2=np.array([KD, RUmin, RUmax])
        residuals = lambda PAR, rX, rY, Pept, fun: rY - COMPLEX(rX, PAR, Pept)    
        vexp2, covar = o.leastsq(residuals, PAR2, args=(rX2, rY2, Pept, COMPLEX))
        Kd2 = vexp2[0]
        dirkd2.append(vexp2[0])
        dirmin2.append(vexp2[1])
        dirmax2.append(vexp2[2])
        if typdir1 > 0:
            if ProtConc > 0:
                if Force < 1:
                    #Unrestrained fit
                    PAR4=np.array([2*v[0], v[1], v[2]])
                    residualscomptit3 = lambda PAR4, rCX, rCY, ProtConc, Pept, Kd, fun: rCY - COMPTITnew(rCX, PAR4, ProtConc, Pept, Kd)
                    (vcomp1, cov_v4) = o.leastsq(residualscomptit3, PAR4, args=(rCX, rCY, ProtConc, Pept, Kd, COMPTITnew))
                    comp1kd.append(vcomp1[0])
                    comp1min.append(vcomp1[1])
                    comp1max.append(vcomp1[2])
                else:
                    #FORCED fit
                    WIN=np.array((v[1], v[2]))
                    PAR3=np.array((0.5*v[0]))
                    residualscomptit2 = lambda PAR3, rCX, rCY, ProtConc, Pept, WIN, Kd, fun: rCY - COMPTIT2force(rCX, PAR3, ProtConc, Pept, Kd, WIN)
                    (vcomp1, cov_v3) = o.leastsq(residualscomptit2, PAR3, args=(rCX, rCY, ProtConc, Pept, WIN, Kd, COMPTIT2))
                    comp1kd.append(vcomp1[0])
                    comp1min.append(v[1])
                    comp1max.append(v[2])
            if ProtConc2 > 0:
                if Force < 1:
                    #Unrestrained fit
                    PAR4=np.array([2*vexp2[0], vexp2[1], vexp2[2]])
                    residualscomptit3 = lambda PAR4, rCX2, rCY2, ProtConc2, Pept, Kd2, fun: rCY2 - COMPTITnew(rCX2, PAR4, ProtConc2, Pept, Kd2)
                    (vcomp2, cov_v4) = o.leastsq(residualscomptit3, PAR4, args=(rCX2, rCY2, ProtConc2, Pept, Kd2, COMPTITnew))
                    comp2kd.append(vcomp2[0])
                    comp2min.append(vcomp2[1])
                    comp2max.append(vcomp2[2])
                else:
                    #FORCED fit
                    WIN=np.array((vexp2[1], vexp2[2]))
                    PAR4=np.array([2*vexp2[0]])
                    residualscomptit3 = lambda PAR4, rCX2, rCY2, ProtConc2, Pept, WIN, Kd2, fun: rCY2 - COMPTITnewforce(rCX2, PAR4, ProtConc2, Pept, Kd2, WIN)
                    (vcomp2, cov_v4) = o.leastsq(residualscomptit3, PAR4, args=(rCX2, rCY2, ProtConc, Pept, WIN, Kd2, COMPTITnewforce))
                    comp2kd.append(vcomp2[0])
                    comp2min.append(vexp2[1])
                    comp2max.append(vexp2[2])
    ##############################################################
    ###########################FIGURE#############################
    ##############################################################
    Cmax = np.max([X, X2])
    Cmin = np.min([X, X2]) 
    Cminlog1= min([n for n in X  if n>0])
    Cminlog2= min([n for n in X2  if n>0])
    Cminlog= np.min([Cminlog1, Cminlog2])
    Cwinddir=Cmax-Cmin
    RUminplt = RUmin 
    RUmaxplt = RUmax 
    FPwindD=RUmax-RUmin
    FPwindDplt = FPwindD 
    aYplt2 = aY2
    sYplt2 = sY2 
    Yplt2 = Y2  
    aYplt = aY 
    sYplt = sY 
    Yplt = Y 
    avdirkd = np.average(dirkd)
    avdirmin = np.average(dirmin)
    avdirmax = np.average(dirmax)
    sddirkd = np.std(dirkd)
    v=np.array((avdirkd, avdirmin, avdirmax))
    if xscale == 0:
        Conc = np.linspace(0,Cmax+0.5,1000)
    else:
        Conc = np.linspace(Cminlog/2,Cmax*2,3000)
    Smod = COMPLEX(Conc, v, Pept)
    avdirkd2 = np.average(dirkd2)
    avdirmin2 = np.average(dirmin2)
    avdirmax2 = np.average(dirmax2)
    sddirkd2 = np.std(dirkd2)
    vexp2=np.array((avdirkd2, avdirmin2, avdirmax2))
    Smodexp2 = COMPLEX(Conc, vexp2, Pept)
    CCminlog1= min([n for n in CX  if n>0])
    CCminlog2= min([n for n in CX2  if n>0])
    CCminlog= np.min([CCminlog1, CCminlog2])
    CCmax = np.max([CX, CX2])
    CCmin = np.min([CX, CX2])
    if xscale == 0:
        Conccomp = np.linspace(0,CCmax+5,1000)
    else:
        Conccomp = np.linspace(CCminlog/2,CCmax*2,3000)
    if typdir1 > 0:
        if ProtConc > 0:
            avcomp1kd = np.average(comp1kd)
            avcomp1min = np.average(comp1min)
            avcomp1max = np.average(comp1max)
            vcomp1fin=np.array((avcomp1kd, avcomp1min, avcomp1max))
            Smodcomp1 = COMPTITnew(Conccomp, vcomp1fin, ProtConc, Pept, Kd)
        if ProtConc2 > 0:
            avcomp2kd = np.average(comp2kd)
            avcomp2min = np.average(comp2min)
            avcomp2max = np.average(comp2max)
            vcomp2fin=np.array((avcomp2kd, avcomp2min, avcomp2max))
            Smodcomp2 = COMPTITnew(Conccomp, vcomp2fin, ProtConc2, Pept, Kd2)
    plt.close()
    #DIRECT plot
    ax = plt.subplot(111)
    plt.plot(Conc, Smod, '-r', linewidth=3)
    plt.plot(Conc, Smodexp2, '-b', linewidth=3) 
    if GraphMode > 0:
        plt.errorbar(rX, aYplt, sYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
        plt.errorbar(rX2, aYplt2, sYplt2, linestyle='None', marker='s', markersize=10, ecolor='0.5', mfc='0.5', mec='0.5', capsize= 10.0, capthick= 2.0)
    else:
        plt.plot(X, Yplt, 'ok', markersize=8)
        plt.plot(X2, Yplt2, 's', mfc='0.5', mec='0.5', markersize=8)
    if xscale == 0:
        plt.axis([Cmin-Cwinddir*0.05,Cmax+Cwinddir*0.05,RUminplt-FPwindDplt*0.1,RUmaxplt+FPwindDplt*0.15])
    else:
        ax.set_xscale('log')
        plt.axis([Cminlog/2,Cmax*2,RUminplt-FPwindDplt*0.1,RUmaxplt+FPwindDplt*0.15])
    plt.title(dirtitl, fontsize=20)
    ax.set_xlabel(labelx1, fontsize=19)
    ax.set_ylabel(labely, fontsize=19)
    ax.tick_params(labelsize=16)
    plt.tight_layout()
    plt.savefig('direct.png')
    plt.close()
    if typdir1 > 0:
        aCYplt = aCY
        sCYplt = sCY
        CYplt = CY
        aCYplt2 = aCY2
        sCYplt2 = sCY2
        CYplt2 = CY2
        plotmax = np.max([RUmax, CRUmax, CRUmax2])
        plotmin = np.min([RUmin, CRUmin, CRUmin2])
        CCwinddir=CCmax-CCmin
        plotminplt = plotmin
        plotmaxplt = plotmax
        plotminplt = plotmin
        FPwindCplt = plotmax-plotmin
        #CRUmaxplt = CRUmax
        #COMPTIT2 plot
        ax = plt.subplot(111)
        if ProtConc > 0:
            plt.plot(Conccomp, Smodcomp1, '-r', linewidth=3)
            if GraphMode > 0:
                plt.errorbar(rCX, aCYplt, sCYplt, linestyle='None', marker='o', markersize=10, ecolor='k', mfc='k', mec='k', capsize= 10.0, capthick= 2.0)
            else:
                plt.plot(CX, CYplt, 'ok', markersize=8)
        if ProtConc2 > 0:
            plt.plot(Conccomp, Smodcomp2, '-b', linewidth=3)
            if GraphMode > 0:
                plt.errorbar(rCX2, aCYplt2, sCYplt2, linestyle='None', marker='s', markersize=10, ecolor='0.5', mfc='0.5', mec='0.5', capsize= 10.0, capthick= 2.0)
            else:
                plt.plot(CX2, CYplt2, 's', mfc='0.5', mec='0.5', markersize=8)
        if xscale == 0:
            plt.axis([CCmin-CCwinddir*0.05,CCmax+CCwinddir*0.05,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
        else:
            ax.set_xscale('log')
            plt.axis([CCminlog/2,CCmax*2,plotminplt-FPwindCplt*0.1,plotmaxplt+FPwindCplt*0.15])
        plt.title(comptitl, fontsize=20)
        ax.set_xlabel(labelx2, fontsize=19)
        ax.set_ylabel(labely, fontsize=19)
        ax.tick_params(labelsize=16)
        plt.tight_layout()
        plt.savefig('competitive.png')
        #plt.show()
        plt.close()
elif v.get() == 3:
    master = Tk()
    master.title("Experiment design")
    concmax=100
    inputkd=10
    tracer=0.05
    protein = 10
    def showdirect():
        v=np.array((float(einputkd.get()), 0, 1))
        if int(xscale.get()) == 0:
            Conc = np.linspace(0,float(econcmax.get())+0.5,1000)
        if int(xscale.get()) > 0:
            Conc = np.logspace(-1.3,np.log10(float(econcmax.get())+0.5),3000)
        Direct = COMPLEX(Conc, v, float(etracer.get()))
        plt.close()
        ax = plt.subplot(111)
        plt.plot(Conc, Direct, '-r', linewidth=3) 
        #plt.hold(True)
        if int(xscale.get()) == 0:
            plt.axis([0-float(econcmax.get())*0.02,float(econcmax.get())*1.02,-0.05,1.05])
        if int(xscale.get()) > 0:
            ax.set_xscale('log')
            plt.axis([0,float(econcmax.get())*1.02,-0.05,1.05])
        ax.set_xlabel('receptor concentration (uM)', fontsize=19)
        ax.set_ylabel('Fraction bound', fontsize=19)
        ax.tick_params(labelsize=16)
        plt.tight_layout()
        plt.show()
        plt.close()
    def showcomp1():
        if int(xscale.get()) == 0:
            Conckomp = np.linspace(0,float(econcmax1.get())+0.5,1000)
        if int(xscale.get()) > 0:
            Conckomp = np.logspace(-1.3,np.log10(float(econcmax1.get())+0.5),3000)
        vcomp1=np.array((float(einputkd1.get()), 0, 1))
        Comp1 = 0
        Comp1 = COMPTITnew(Conckomp, vcomp1, float(eprot1.get()), float(etracer.get()), float(einputkd.get()))  
        plt.close()
        ax = plt.subplot(111)
        plt.plot(Conckomp, Comp1, '-r', linewidth=3) 
        #plt.hold(True)
        if int(xscale.get()) == 0:
            plt.axis([0-float(econcmax1.get())*0.02,float(econcmax1.get())*1.02,-0.05,1.05])
        if int(xscale.get()) > 0:
            ax.set_xscale('log')
            plt.axis([0,float(econcmax1.get())*1.02,-0.05,1.05])
        ax.set_xlabel('ligand concentration (uM)', fontsize=19)
        ax.set_ylabel('Fraction bound', fontsize=19)
        ax.tick_params(labelsize=16)
        plt.tight_layout()
        plt.show()
        plt.close()            
    def showcomp2():
        if int(xscale.get()) == 0:
            Conckomp = np.linspace(0,float(econcmax1.get())+0.5,1000)
        if int(xscale.get()) > 0:
            Conckomp = np.logspace(-1.3,np.log10(float(econcmax1.get())+0.5),3000)
        vcomp1=np.array((float(einputkd1.get()), 0, 1))
        Comp1 = 0
        vcomp2=np.array((float(einputkd2.get()), 0, 1))
        Comp2 = 0  
        Comp1 = COMPTITnew(Conckomp, vcomp1, float(eprot1.get()), float(etracer.get()), float(einputkd.get()))
        Comp2 = COMPTITnew(Conckomp, vcomp2, float(eprot2.get()), float(etracer.get()), float(einputkd.get()))
        plt.close()
        ax = plt.subplot(111)
        plt.plot(Conckomp, Comp1, '-r', linewidth=3) 
        plt.plot(Conckomp, Comp2, '-b', linewidth=3)
        #plt.hold(True)
        ax.set_xlabel('ligand concentration (uM)', fontsize=19)
        ax.set_ylabel('Fraction bound', fontsize=19)
        if int(xscale.get()) == 0:
            plt.axis([0-float(econcmax1.get())*0.02,float(econcmax1.get())*1.02,-0.05,1.05])
        if int(xscale.get()) > 0:
            ax.set_xscale('log')
            plt.axis([0,float(econcmax1.get())*1.02,-0.05,1.05])
        ax.tick_params(labelsize=16)
        plt.tight_layout()
        plt.show()
        plt.close() 
    w = tk.Label(master, font = "Verdana 10 bold", text='DIRECT EXPERIMENT').grid(row=1, column=0)
    w = tk.Label(master, font = "Verdana 10 bold", text='#####PARAMETERS#####').grid(row=1, column=1)
    Label(master, text="Dissociation constant (Kd) = ").grid(row=2)
    einputkd = Entry(master)
    einputkd.insert(10,inputkd)
    einputkd.grid(row=2, column=1)
    Label(master, text="Tracer concentration = ").grid(row=3)
    etracer = Entry(master)
    etracer.insert(10,tracer)
    etracer.grid(row=3, column=1)
    Label(master, text="Titration start at = ").grid(row=4)
    econcmax = Entry(master)
    econcmax.insert(10,concmax)
    econcmax.grid(row=4, column=1)
    button1 = tk.Button(master, text='Show direct', width=12, command=showdirect)
    button1.grid(row=5, column=1)
    w = tk.Label(master, font = "Verdana 10 bold", text='(1) COMPETITIVE EXPERIMENT').grid(row=6, column=0)
    w = tk.Label(master, font = "Verdana 10 bold", text='###PARAMETERS###').grid(row=6, column=1)
    Label(master, text="Dissociation constant (Kd) = ").grid(row=7)
    einputkd1 = Entry(master)
    einputkd1.insert(10,inputkd)
    einputkd1.grid(row=7, column=1)
    Label(master, text="Protein concentration = ").grid(row=8)
    eprot1 = Entry(master)
    eprot1.insert(10,protein)
    eprot1.grid(row=8, column=1)
    Label(master, text="Titration start at = ").grid(row=9)
    econcmax1 = Entry(master)
    econcmax1.insert(10,concmax)
    econcmax1.grid(row=9, column=1)
    button2 = tk.Button(master, text='Show (1) competitive', width=20, command=showcomp1)
    button2.grid(row=11, column=1)
    w = tk.Label(master, font = "Verdana 10 bold", text='(2) COMPETITIVE EXPERIMENT').grid(row=12, column=0)
    w = tk.Label(master, font = "Verdana 10 bold", text='###PARAMETERS###').grid(row=12, column=1)
    Label(master, text="Dissociation constant (Kd) = ").grid(row=13)
    einputkd2 = Entry(master)
    einputkd2.insert(10,inputkd)
    einputkd2.grid(row=13, column=1)
    Label(master, text="Protein concentration = ").grid(row=14)
    eprot2 = Entry(master)
    eprot2.insert(10,protein)
    eprot2.grid(row=14, column=1)
    button2 = tk.Button(master, text='Show (1+2) competitive', width=20, command=showcomp2)
    button2.grid(row=15, column=1)
    Label(master, text="X scale type (0 or 1) = ").grid(row=16)
    xscale = Entry(master)
    xscale.insert(10,0)
    xscale.grid(row=16, column=1)
    button = tk.Button(master, text='Exit', width=12, command=master.destroy)
    button.grid(row=17, column=1)
    mainloop()

